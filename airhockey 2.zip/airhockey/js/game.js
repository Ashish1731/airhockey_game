const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const celebrationCanvas = document.getElementById("celebrationCanvas");
const celebrationCtx = celebrationCanvas.getContext("2d");
const restartBtn = document.getElementById("restartBtn");
const readyText = document.getElementById("readyText");
const pauseBtn = document.getElementById("pauseBtn");
const pauseOverlay = document.getElementById("pauseOverlay");
const resumeBtn = document.getElementById("resumeBtn");
const finalScoreOverlay = document.getElementById("finalScoreOverlay");
const finalScoreDisplay = document.getElementById("finalScoreDisplay");
const finalScoreWinner = document.getElementById("finalScoreWinner");
const finalScoreText = document.getElementById("finalScoreText");
const matchPointOverlay = document.getElementById("matchPointOverlay");
const matchPointText = document.getElementById("matchPointText");
const matchPointSubtext = document.getElementById("matchPointSubtext");
const settingsBtn = document.getElementById("settingsBtn");
const settingsOverlay = document.getElementById("settingsOverlay");
const settingsCloseBtn = document.getElementById("settingsCloseBtn");
const rotatePrompt = document.getElementById("rotatePrompt");
const rotateDismissBtn = document.getElementById("rotateDismissBtn");

// ============ ROTATE PROMPT ============
let rotatePromptDismissed = false;

// Check if device is in portrait mode on mobile
function checkOrientation() {
    const isMobile = window.innerWidth <= 768;
    const isPortrait = window.innerHeight > window.innerWidth;

    // Only show on mobile in portrait mode and if not dismissed
    if (isMobile && isPortrait && !rotatePromptDismissed) {
        rotatePrompt.classList.add('show');
        // Pause the game when prompt is shown
        if (!paused && isPuckLaunched) {
            togglePause();
        }
    } else {
        rotatePrompt.classList.remove('show');
    }
}

// Dismiss the rotate prompt
rotateDismissBtn.addEventListener('click', () => {
    rotatePromptDismissed = true;
    rotatePrompt.classList.remove('show');
});

// Check orientation on load and resize
window.addEventListener('load', checkOrientation);
window.addEventListener('resize', checkOrientation);

// Also check when orientation changes
if (window.screen && window.screen.orientation) {
    window.screen.orientation.addEventListener('change', checkOrientation);
}

// AI Difficulty settings
let aiDifficulty = 'medium';
let winScore = 5;

// Difficulty configurations
const DIFFICULTY_CONFIG = {
    easy: {
        speed: 0.15,
        errorMargin: 30,
        aggressiveness: 0.12,
        reactionDelay: 15,
        predictionFrames: 14,
        powerMultiplier: 0.9,
        description: 'Casual play - AI is slow and makes mistakes'
    },
    medium: {
        speed: 0.22,
        errorMargin: 12,
        aggressiveness: 0.22,
        reactionDelay: 6,
        predictionFrames: 20,
        powerMultiplier: 1.0,
        description: 'Balanced challenge for casual play'
    },
    hard: {
        speed: 0.35,
        errorMargin: 2,
        aggressiveness: 0.40,
        reactionDelay: 1,
        predictionFrames: 32,
        powerMultiplier: 1.5,
        description: 'Expert level - AI reacts quickly and precisely'
    }
};

// Audio
let audioCtx = null;
let audioInitialized = false;

function initAudio() {
    try {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            audioInitialized = true;
        }
        if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        return true;
    } catch (e) {
        console.warn('Audio initialization failed:', e);
        return false;
    }
}

function ensureAudio() {
    if (!audioInitialized || !audioCtx) {
        return initAudio();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
    return true;
}

function playHitSound(pitch = 440, duration = 0.05, volume = 0.2) {
    try {
        if (!ensureAudio() || !audioCtx) return;
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.frequency.value = pitch;
        oscillator.type = 'sine';
        gainNode.gain.setValueAtTime(volume, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
        oscillator.start();
        oscillator.stop(audioCtx.currentTime + duration);
    } catch (e) { }
}

function playGoalSound() {
    try {
        if (!ensureAudio() || !audioCtx) return;
        const notes = [523, 659, 784, 1047];
        notes.forEach((freq, i) => {
            setTimeout(() => {
                playHitSound(freq, 0.12, 0.15);
            }, i * 80);
        });
    } catch (e) { }
}

function resize() {
    const container = document.getElementById('gameContainer');
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    celebrationCanvas.width = container.clientWidth;
    celebrationCanvas.height = container.clientHeight;
}

resize();
window.addEventListener("resize", resize);

// Initialize audio on any user interaction
document.addEventListener('click', () => { initAudio(); }, { once: false });
document.addEventListener('touchstart', () => { initAudio(); }, { once: false });
document.addEventListener('keydown', () => { initAudio(); }, { once: false });

const GOAL_HEIGHT = 180;
const MIN_PUCK_SPEED = 5;
const MAX_PUCK_SPEED = 22;
const FIXED_DT = 1 / 60;

let playerScore = 0;
let aiScore = 0;
let gameOver = false;
let paused = false;
let countdown = 0;
let goalFlash = 0;
let particles = [];
let trails = [];
let celebrationParticles = [];
let impactGlows = [];
let isPuckLaunched = false;
let countdownTimer = null;
let stuckTimer = 0;
let scorePop = '';
let isTabVisible = true;
let goalAnimationActive = false;
let goalAnimationTimer = null;
let stuckPuckResetTimer = 0;
let isNotificationActive = false;
let aiHitTimer = 0;
let aiRandomDelay = 0;
let gameEnded = false;
let matchPointShown = false;
let matchPointTimer = null;
let accumulator = 0;
let lastTimestamp = 0;
let aiHitsInRow = 0;
let aiStuckTimer = 0;
let aiTargetX = 0;
let aiTargetY = 0;

let mouseX = 150;
let mouseY = window.innerHeight / 2;
let lastCollisionTime = 0;

// Static air pocket positions
let airPockets = [];

function generateAirPockets() {
    airPockets = [];
    const pocketRadius = 2.5;
    const pocketSpacing = 40;

    const startX = 40;
    const endX = canvas.width - 40;
    const startY = 40;
    const endY = canvas.height - 40;
    const goalTop = canvas.height / 2 - GOAL_HEIGHT / 2;

    for (let y = startY; y < endY; y += pocketSpacing) {
        for (let x = startX; x < endX; x += pocketSpacing) {
            const px = x;
            const py = y;

            const distFromCenter = Math.hypot(px - canvas.width / 2, py - canvas.height / 2);
            if (distFromCenter < 75) continue;

            if (px < 30 && py > goalTop && py < goalTop + GOAL_HEIGHT) continue;
            if (px > canvas.width - 30 && py > goalTop && py < goalTop + GOAL_HEIGHT) continue;

            airPockets.push({ x: px, y: py });
        }
    }
}

generateAirPockets();
window.addEventListener('resize', () => {
    resize();
    generateAirPockets();
    player.x = Math.min(player.x, canvas.width / 2 - player.radius);
    ai.x = Math.max(ai.x, canvas.width / 2 + ai.radius);
});

// Game objects
const player = {
    x: 150,
    y: canvas.height / 2,
    radius: 35,
    targetX: 150,
    targetY: canvas.height / 2
};

const ai = {
    x: canvas.width - 150,
    y: canvas.height / 2,
    radius: 35,
    targetX: canvas.width - 150,
    targetY: canvas.height / 2,
    errorMargin: 0,
    aggressiveness: 0,
    velocityY: 0,
    predictionFrames: 15,
    hitCounter: 0,
    reactionSpeed: 0.12,
    smoothX: 0,
    smoothY: 0,
    targetX: 0,
    targetY: 0
};

const puck = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    radius: 18,
    vx: 0,
    vy: 0
};

// Show cursor helper
function showCursor() {
    document.body.classList.add('show-cursor');
}

function hideCursor() {
    if (!settingsOverlay.classList.contains('show') &&
        !pauseOverlay.classList.contains('show') &&
        !gameOver) {
        document.body.classList.remove('show-cursor');
    }
}

// Settings
function applyDifficulty() {
    const config = DIFFICULTY_CONFIG[aiDifficulty];
    ai.errorMargin = config.errorMargin;
    ai.aggressiveness = config.aggressiveness;
    ai.predictionFrames = config.predictionFrames;
    ai.reactionSpeed = config.speed;
    aiRandomDelay = config.reactionDelay;
    ai.smoothX = ai.x;
    ai.smoothY = ai.y;

    document.getElementById('difficultyDesc').textContent = config.description;
}

applyDifficulty();

// Settings event listeners
settingsBtn.addEventListener("click", () => {
    if (gameOver || paused) return;
    showCursor();
    settingsOverlay.classList.add('show');
});

settingsCloseBtn.addEventListener("click", () => {
    settingsOverlay.classList.remove('show');
    hideCursor();
});

// Difficulty buttons
document.querySelectorAll('.diff-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.diff-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        aiDifficulty = btn.dataset.difficulty;
        applyDifficulty();
        ai.smoothX = ai.x;
        ai.smoothY = ai.y;
    });
});

// Win score buttons
document.querySelectorAll('.score-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.score-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        winScore = parseInt(btn.dataset.score);
    });
});

// Visibility detection
document.addEventListener("visibilitychange", () => {
    isTabVisible = !document.hidden;
    if (!isTabVisible && !gameOver && isPuckLaunched && !paused && !isNotificationActive) {
        togglePause();
    }
});

// Pause
function togglePause() {
    if (isNotificationActive || countdown > 0 || goalAnimationActive) return;
    if (gameOver) return;
    if (!isPuckLaunched) return;

    paused = !paused;
    if (paused) {
        pauseOverlay.classList.add('show');
        pauseBtn.textContent = 'Resume';
        showCursor();
    } else {
        pauseOverlay.classList.remove('show');
        pauseBtn.textContent = 'Pause';
        hideCursor();
        if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        lastTimestamp = performance.now();
    }
}

pauseBtn.addEventListener("click", togglePause);
resumeBtn.addEventListener("click", togglePause);

document.addEventListener("keydown", (e) => {
    if (e.code === 'Space' && !gameOver) {
        e.preventDefault();
        if (isNotificationActive || countdown > 0 || goalAnimationActive) return;
        if (!isPuckLaunched) return;
        togglePause();
    }
});

// Mouse/Touch
canvas.addEventListener("mousemove", (e) => {
    if (paused || gameOver || goalAnimationActive || isNotificationActive) return;
    const rect = canvas.getBoundingClientRect();
    mouseX = e.clientX - rect.left;
    mouseY = e.clientY - rect.top;
    player.targetX = Math.max(player.radius + 20, Math.min(canvas.width / 2 - player.radius, mouseX));
    player.targetY = Math.max(player.radius + 20, Math.min(canvas.height - player.radius - 20, mouseY));
});

canvas.addEventListener("touchmove", (e) => {
    if (paused || gameOver || goalAnimationActive || isNotificationActive) return;
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    if (touch) {
        mouseX = touch.clientX - rect.left;
        mouseY = touch.clientY - rect.top;
        player.targetX = Math.max(player.radius + 20, Math.min(canvas.width / 2 - player.radius, mouseX));
        player.targetY = Math.max(player.radius + 20, Math.min(canvas.height - player.radius - 20, mouseY));
    }
}, { passive: false });

canvas.addEventListener("touchstart", (e) => {
    if (paused || gameOver || goalAnimationActive || isNotificationActive) return;
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    if (touch) {
        mouseX = touch.clientX - rect.left;
        mouseY = touch.clientY - rect.top;
        player.targetX = Math.max(player.radius + 20, Math.min(canvas.width / 2 - player.radius, mouseX));
        player.targetY = Math.max(player.radius + 20, Math.min(canvas.height - player.radius - 20, mouseY));
    }
    initAudio();
}, { passive: false });

restartBtn.addEventListener("click", () => {
    initAudio();
    playerScore = 0;
    aiScore = 0;
    gameOver = false;
    gameEnded = false;
    paused = false;
    goalAnimationActive = false;
    isNotificationActive = false;
    stuckPuckResetTimer = 0;
    aiHitTimer = 0;
    aiRandomDelay = 0;
    ai.hitCounter = 0;
    aiHitsInRow = 0;
    aiStuckTimer = 0;
    matchPointShown = false;
    accumulator = 0;
    lastTimestamp = performance.now();
    if (matchPointTimer) {
        clearTimeout(matchPointTimer);
        matchPointTimer = null;
    }
    matchPointOverlay.classList.remove('show');
    finalScoreOverlay.classList.remove('show');
    celebrationCanvas.classList.remove('show');
    if (goalAnimationTimer) {
        clearTimeout(goalAnimationTimer);
        goalAnimationTimer = null;
    }
    pauseOverlay.classList.remove('show');
    document.body.classList.remove('show-cursor');
    pauseBtn.textContent = 'Pause';
    restartBtn.classList.remove('show');
    readyText.classList.remove('show');
    particles = [];
    trails = [];
    celebrationParticles = [];
    impactGlows = [];
    isPuckLaunched = false;
    stuckTimer = 0;
    ai.errorMargin = 0;
    ai.velocityY = 0;
    ai.smoothX = ai.x;
    ai.smoothY = ai.y;
    if (countdownTimer) {
        clearTimeout(countdownTimer);
        countdownTimer = null;
    }
    updateScoreDisplay();
    resetPuck();
});

function updateScoreDisplay() {
    const playerSide = document.getElementById("playerScoreSide");
    const aiSide = document.getElementById("aiScoreSide");

    playerSide.textContent = playerScore;
    aiSide.textContent = aiScore;

    if (scorePop === 'player') {
        playerSide.classList.remove('pop-side');
        void playerSide.offsetWidth;
        playerSide.classList.add('pop-side');
    } else if (scorePop === 'ai') {
        aiSide.classList.remove('pop-side');
        void aiSide.offsetWidth;
        aiSide.classList.add('pop-side');
    }
    scorePop = '';
}

function showMatchPoint() {
    if (matchPointShown) return;
    matchPointShown = true;

    matchPointOverlay.classList.add('show');
    matchPointText.textContent = '⚡ MATCH POINT ⚡';

    if (playerScore === winScore - 1) {
        matchPointSubtext.textContent = 'YOU are one point away from winning!';
        matchPointText.style.color = '#60a5fa';
        matchPointText.style.textShadow = '0 0 60px rgba(96, 165, 250, 0.5), 0 0 120px rgba(96, 165, 250, 0.3)';
    } else if (aiScore === winScore - 1) {
        matchPointSubtext.textContent = 'AI is one point away from winning!';
        matchPointText.style.color = '#f87171';
        matchPointText.style.textShadow = '0 0 60px rgba(248, 113, 113, 0.5), 0 0 120px rgba(248, 113, 113, 0.3)';
    }

    if (matchPointTimer) clearTimeout(matchPointTimer);
    matchPointTimer = setTimeout(() => {
        matchPointOverlay.classList.remove('show');
        matchPointTimer = null;
    }, 2000);
}

function showFinalScore() {
    gameEnded = true;
    finalScoreOverlay.classList.add('show');
    showCursor();

    const isWin = playerScore > aiScore;
    const isDraw = playerScore === aiScore;

    finalScoreText.textContent = '🏆 GAME OVER 🏆';
    finalScoreDisplay.textContent = `${playerScore} - ${aiScore}`;

    if (isDraw) {
        finalScoreWinner.textContent = "IT'S A DRAW! 🤝";
        finalScoreWinner.className = 'draw';
    } else if (isWin) {
        finalScoreWinner.textContent = 'YOU WIN! 🎉';
        finalScoreWinner.className = 'win';
    } else {
        finalScoreWinner.textContent = 'AI WINS! 🤖';
        finalScoreWinner.className = 'lose';
    }
}

function createImpactGlow(x, y, color, size = 60, isWall = false) {
    impactGlows.push({
        x, y,
        radius: isWall ? 2 : 5,
        maxRadius: size,
        color: color,
        life: 1,
        decay: 0.02 + Math.random() * 0.015,
        isWall: isWall
    });
    if (impactGlows.length > 15) {
        impactGlows.shift();
    }
}

function updateImpactGlows() {
    for (let i = impactGlows.length - 1; i >= 0; i--) {
        const g = impactGlows[i];
        g.radius += (g.maxRadius - g.radius) * 0.1;
        g.life -= g.decay;
        if (g.life <= 0) {
            impactGlows.splice(i, 1);
        }
    }
}

function drawImpactGlows() {
    impactGlows.forEach(g => {
        const alpha = g.life * 0.5;

        if (g.isWall) {
            const grad = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, g.radius);
            grad.addColorStop(0, g.color.replace(')', `,${alpha * 0.3})`).replace('rgb', 'rgba'));
            grad.addColorStop(0.5, g.color.replace(')', `,${alpha * 0.6})`).replace('rgb', 'rgba'));
            grad.addColorStop(1, g.color.replace(')', `,0)`).replace('rgb', 'rgba'));
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(g.x, g.y, g.radius, 0, Math.PI * 2);
            ctx.fill();

            ctx.strokeStyle = g.color.replace(')', `,${alpha * 0.8})`).replace('rgb', 'rgba');
            ctx.lineWidth = 2 + g.life * 3;
            ctx.shadowColor = g.color;
            ctx.shadowBlur = 20;
            ctx.beginPath();
            ctx.arc(g.x, g.y, g.radius * 0.6, 0, Math.PI * 2);
            ctx.stroke();
            ctx.shadowBlur = 0;
        } else {
            const grad = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, g.radius);
            grad.addColorStop(0, g.color.replace(')', `,${alpha * 0.8})`).replace('rgb', 'rgba'));
            grad.addColorStop(0.3, g.color.replace(')', `,${alpha * 0.5})`).replace('rgb', 'rgba'));
            grad.addColorStop(1, g.color.replace(')', `,0)`).replace('rgb', 'rgba'));
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(g.x, g.y, g.radius, 0, Math.PI * 2);
            ctx.fill();

            const coreGrad = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, g.radius * 0.2);
            coreGrad.addColorStop(0, `rgba(255, 255, 255, ${alpha * 0.6})`);
            coreGrad.addColorStop(1, `rgba(255, 255, 255, 0)`);
            ctx.fillStyle = coreGrad;
            ctx.beginPath();
            ctx.arc(g.x, g.y, g.radius * 0.2, 0, Math.PI * 2);
            ctx.fill();
        }
    });
}

// ============ CELEBRATION FUNCTIONS ============

function createCelebrationBurst(x, y, color1, color2, text = 'GOAL!') {
    isNotificationActive = true;
    celebrationCanvas.classList.add('show');
    celebrationParticles = [];

    const particleCount = 50;
    const sparkleCount = 20;

    for (let i = 0; i < particleCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 8 + 3;
        const size = Math.random() * 5 + 2;
        const color = Math.random() > 0.5 ? color1 : color2;
        celebrationParticles.push({
            x, y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed - 2,
            radius: size,
            color: color,
            life: 1,
            decay: 0.012 + Math.random() * 0.015,
            gravity: 0.1,
            rotation: Math.random() * Math.PI * 2,
            rotSpeed: (Math.random() - 0.5) * 0.08
        });
    }

    for (let i = 0; i < sparkleCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 6 + 2;
        celebrationParticles.push({
            x, y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed - 3,
            radius: Math.random() * 2 + 1,
            color: '#ffffff',
            life: 1,
            decay: 0.02 + Math.random() * 0.02,
            gravity: 0.04,
            rotation: 0,
            rotSpeed: 0,
            sparkle: true
        });
    }

    const chars = text.split('');
    const totalChars = chars.length;
    const radius = 90;
    chars.forEach((char, index) => {
        const angle = (index / totalChars) * Math.PI * 2 - Math.PI / 2;
        const xPos = x + Math.cos(angle) * radius;
        const yPos = y + Math.sin(angle) * radius;
        celebrationParticles.push({
            x: xPos,
            y: yPos,
            vx: Math.cos(angle) * 2,
            vy: Math.sin(angle) * 2 - 2,
            radius: 14,
            color: '#fbbf24',
            life: 1,
            decay: 0.008,
            gravity: 0.015,
            text: char,
            isText: true,
            rotation: angle,
            rotSpeed: 0.015
        });
    });

    if (goalAnimationTimer) clearTimeout(goalAnimationTimer);
    goalAnimationTimer = setTimeout(() => {
        celebrationCanvas.classList.remove('show');
        celebrationParticles = [];
        goalAnimationActive = false;
        isNotificationActive = false;
        goalAnimationTimer = null;
        setTimeout(() => {
            if (!gameOver && !gameEnded) resetPuck();
        }, 300);
    }, 2000);
}

function updateCelebration() {
    for (let i = celebrationParticles.length - 1; i >= 0; i--) {
        const p = celebrationParticles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += p.gravity || 0;
        p.vx *= 0.99;
        p.vy *= 0.99;
        p.life -= p.decay;
        p.radius *= 0.998;
        if (p.rotation !== undefined) {
            p.rotation += p.rotSpeed || 0;
        }
        if (p.life <= 0 || p.radius < 0.3) {
            celebrationParticles.splice(i, 1);
        }
    }
}

function drawCelebration() {
    const cctx = celebrationCtx;
    const width = celebrationCanvas.width;
    const height = celebrationCanvas.height;

    cctx.clearRect(0, 0, width, height);

    const len = celebrationParticles.length;
    for (let i = 0; i < len; i++) {
        const p = celebrationParticles[i];
        cctx.save();
        cctx.globalAlpha = p.life;

        if (p.isText) {
            cctx.translate(p.x, p.y);
            cctx.rotate(p.rotation || 0);
            cctx.font = `bold ${p.radius * 1.5}px "Segoe UI", "Arial", sans-serif`;
            cctx.textAlign = 'center';
            cctx.textBaseline = 'middle';
            cctx.shadowColor = 'rgba(251, 191, 36, 0.5)';
            cctx.shadowBlur = 20;
            cctx.fillStyle = p.color;
            cctx.fillText(p.text, 0, 0);
        } else if (p.sparkle) {
            cctx.shadowColor = p.color;
            cctx.shadowBlur = 15;
            cctx.fillStyle = p.color;
            cctx.beginPath();
            cctx.arc(p.x, p.y, p.radius * p.life, 0, Math.PI * 2);
            cctx.fill();
        } else {
            cctx.shadowColor = p.color;
            cctx.shadowBlur = 12;
            cctx.fillStyle = p.color;
            cctx.beginPath();
            cctx.arc(p.x, p.y, p.radius * p.life, 0, Math.PI * 2);
            cctx.fill();
        }

        cctx.restore();
    }
    cctx.globalAlpha = 1;
    cctx.shadowBlur = 0;
}

function launchPuck() {
    if (gameOver || gameEnded) return;
    const direction = Math.random() > 0.5 ? 1 : -1;
    puck.vx = direction * (6 + Math.random() * 3);
    puck.vy = (Math.random() - 0.5) * 6;
    clampSpeed();
    isPuckLaunched = true;
    readyText.classList.remove('show');
    isNotificationActive = false;
    countdown = 0;
    stuckTimer = 0;
    stuckPuckResetTimer = 0;
    ai.hitCounter = 0;
    aiHitsInRow = 0;
    aiStuckTimer = 0;
    aiRandomDelay = DIFFICULTY_CONFIG[aiDifficulty].reactionDelay;
}

function resetPuck() {
    puck.x = canvas.width / 2;
    puck.y = canvas.height / 2;
    puck.vx = 0;
    puck.vy = 0;
    isPuckLaunched = false;
    countdown = 60;
    stuckTimer = 0;
    stuckPuckResetTimer = 0;
    ai.hitCounter = 0;
    aiHitsInRow = 0;
    aiStuckTimer = 0;

    if (countdownTimer) {
        clearTimeout(countdownTimer);
        countdownTimer = null;
    }

    if (!gameOver && !goalAnimationActive && !gameEnded) {
        isNotificationActive = true;
        readyText.classList.add('show');
        countdownTimer = setTimeout(() => {
            launchPuck();
            countdownTimer = null;
        }, 1000);
    }
}

function clampSpeed() {
    const speed = Math.hypot(puck.vx, puck.vy);
    if (speed < MIN_PUCK_SPEED && speed > 0) {
        puck.vx = (puck.vx / speed) * MIN_PUCK_SPEED;
        puck.vy = (puck.vy / speed) * MIN_PUCK_SPEED;
    }
    if (speed > MAX_PUCK_SPEED) {
        puck.vx = (puck.vx / speed) * MAX_PUCK_SPEED;
        puck.vy = (puck.vy / speed) * MAX_PUCK_SPEED;
    }
}

function createParticles(x, y, color, count = 10, speed = 4) {
    const maxParticles = 60;
    for (let i = 0; i < Math.min(count, maxParticles - particles.length); i++) {
        const angle = Math.random() * Math.PI * 2;
        const spd = Math.random() * speed + 1;
        particles.push({
            x, y,
            vx: Math.cos(angle) * spd,
            vy: Math.sin(angle) * spd,
            radius: Math.random() * 2 + 1,
            color: color,
            life: 1,
            decay: 0.02 + Math.random() * 0.03
        });
    }
}

function createTrail() {
    if (isPuckLaunched && Math.hypot(puck.vx, puck.vy) > 3) {
        trails.push({
            x: puck.x,
            y: puck.y,
            radius: puck.radius * 0.3,
            life: 1,
            decay: 0.08
        });
        if (trails.length > 10) trails.shift();
    }
}

function updateParticles() {
    for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.97;
        p.vy *= 0.97;
        p.life -= p.decay;
        if (p.life <= 0) particles.splice(i, 1);
    }
    for (let i = trails.length - 1; i >= 0; i--) {
        trails[i].life -= trails[i].decay;
        trails[i].radius *= 0.96;
        if (trails[i].life <= 0) trails.splice(i, 1);
    }
    updateImpactGlows();
}

function updatePaddle(paddle, targetX, targetY, minX, maxX, speed) {
    const oldX = paddle.x;
    const oldY = paddle.y;

    let actualSpeed = speed;
    if (paddle === ai) {
        const lerpSpeed = Math.min(actualSpeed, 0.35);
        paddle.x += (targetX - paddle.x) * lerpSpeed;
        paddle.y += (targetY - paddle.y) * lerpSpeed;
    } else {
        paddle.x += (targetX - paddle.x) * Math.min(actualSpeed, 0.30);
        paddle.y += (targetY - paddle.y) * Math.min(actualSpeed, 0.30);
    }

    paddle.x = Math.max(minX, Math.min(maxX, paddle.x));
    paddle.y = Math.max(paddle.radius + 20, Math.min(canvas.height - paddle.radius - 20, paddle.y));
    return { vx: paddle.x - oldX, vy: paddle.y - oldY };
}

function handleCollision(paddle, velocity) {
    const now = Date.now();
    if (now - lastCollisionTime < 40) return;

    const dx = puck.x - paddle.x;
    const dy = puck.y - paddle.y;
    const distance = Math.hypot(dx, dy);
    const minDistance = puck.radius + paddle.radius;
    if (distance >= minDistance) return;

    lastCollisionTime = now;
    const nx = dx / distance;
    const ny = dy / distance;
    puck.x = paddle.x + nx * (minDistance + 2);
    puck.y = paddle.y + ny * (minDistance + 2);
    const hitStrength = Math.hypot(velocity.vx, velocity.vy) * 2;

    const config = DIFFICULTY_CONFIG[aiDifficulty];
    const powerMult = paddle === ai ? config.powerMultiplier : 1.0;

    if (paddle === ai) {
        ai.hitCounter++;
        aiHitsInRow++;
        const variation = 0.15 + Math.min(ai.hitCounter * 0.01, 0.35);
        const angleOffset = (Math.random() - 0.5) * variation * Math.PI;
        const currentAngle = Math.atan2(ny, nx);
        const newAngle = currentAngle + angleOffset;
        const nx2 = Math.cos(newAngle);
        const ny2 = Math.sin(newAngle);

        const powerVariation = 0.9 + Math.random() * 0.3;
        const finalPower = Math.max(10, hitStrength * powerVariation * powerMult);
        puck.vx = nx2 * finalPower + velocity.vx * 0.3 + (Math.random() - 0.5) * 2;
        puck.vy = ny2 * finalPower + velocity.vy * 0.3 + (Math.random() - 0.5) * 2;

        if (aiDifficulty === 'hard') {
            const aimAngle = Math.atan2(canvas.height / 2 - puck.y, canvas.width / 2 - puck.x);
            puck.vx += Math.cos(aimAngle) * 4;
            puck.vy += Math.sin(aimAngle) * 4;
        }

        if (aiHitsInRow > 2) {
            const centerAngle = Math.atan2(canvas.height / 2 - puck.y, canvas.width / 2 - puck.x);
            const pushStrength = 3 + aiHitsInRow * 0.3;
            puck.vx += Math.cos(centerAngle) * pushStrength;
            puck.vy += Math.sin(centerAngle) * pushStrength;
            aiHitsInRow = 0;
            aiStuckTimer = 0;
        }

        aiStuckTimer = 0;

        if (ai.hitCounter > 10) {
            ai.hitCounter = 0;
        }
    } else {
        puck.vx = nx * Math.max(8, hitStrength) + velocity.vx * 0.2 + (Math.random() - 0.5) * 1;
        puck.vy = ny * Math.max(8, hitStrength) + velocity.vy * 0.2 + (Math.random() - 0.5) * 1;
        aiHitsInRow = 0;
    }

    clampSpeed();

    const pitch = 300 + Math.random() * 300;
    playHitSound(pitch, 0.04, 0.2);
    const color = paddle === player ? '#60a5fa' : '#f87171';
    createParticles(puck.x, puck.y, color, 8, 4);

    const glowColor = paddle === player ? 'rgb(96, 165, 250)' : 'rgb(248, 113, 113)';
    createImpactGlow(puck.x, puck.y, glowColor, 40 + Math.random() * 20, false);
}

function checkPuckStuck() {
    if (!isPuckLaunched || gameOver || gameEnded) return;

    const speed = Math.hypot(puck.vx, puck.vy);

    if (speed < 0.8) {
        stuckTimer++;
        aiStuckTimer++;
    } else {
        stuckTimer = 0;
        stuckPuckResetTimer = 0;
    }

    if (aiStuckTimer > 50 && puck.x > canvas.width / 2) {
        const centerAngle = Math.atan2(canvas.height / 2 - puck.y, canvas.width / 2 - puck.x);
        const pushStrength = 5 + aiStuckTimer * 0.08;
        puck.vx += Math.cos(centerAngle) * pushStrength;
        puck.vy += Math.sin(centerAngle) * pushStrength;
        clampSpeed();
        aiStuckTimer = 0;
        createParticles(puck.x, puck.y, '#ffffff', 10, 4);
    }

    if (stuckTimer > 180) {
        createParticles(puck.x, puck.y, '#ffffff', 15, 6);
        createImpactGlow(puck.x, puck.y, 'rgb(255, 255, 255)', 60, false);
        playHitSound(500, 0.1, 0.3);

        puck.x = canvas.width / 2;
        puck.y = canvas.height / 2;
        const direction = Math.random() > 0.5 ? 1 : -1;
        puck.vx = direction * (7 + Math.random() * 4);
        puck.vy = (Math.random() - 0.5) * 7;
        clampSpeed();
        stuckTimer = 0;
        stuckPuckResetTimer = 0;
        ai.hitCounter = 0;
        aiHitsInRow = 0;
        aiStuckTimer = 0;

        isNotificationActive = true;
        readyText.classList.add('show');
        setTimeout(() => {
            if (!gameOver && !gameEnded) {
                readyText.classList.remove('show');
                isNotificationActive = false;
            }
        }, 500);
    }
}

function updateAI() {
    if (!isPuckLaunched || gameOver || gameEnded) {
        return {
            targetX: ai.x,
            targetY: ai.y,
            speed: 0.05
        };
    }

    aiRandomDelay--;
    if (aiRandomDelay > 0) {
        return {
            targetX: ai.targetX || ai.x,
            targetY: ai.targetY || ai.y,
            speed: 0.10
        };
    }
    aiRandomDelay = DIFFICULTY_CONFIG[aiDifficulty].reactionDelay + Math.random() * 3;

    const puckSpeed = Math.hypot(puck.vx, puck.vy);
    const config = DIFFICULTY_CONFIG[aiDifficulty];

    ai.predictionFrames = config.predictionFrames + Math.min(8, puckSpeed / 2.5);
    ai.velocityY = puck.vy * 0.6 + ai.velocityY * 0.4;

    let predictedX = puck.x + puck.vx * ai.predictionFrames * 0.6;
    let predictedY = puck.y + ai.velocityY * ai.predictionFrames * 0.6;

    const topWall = 20 + puck.radius;
    const bottomWall = canvas.height - 20 - puck.radius;
    const leftWall = 20 + puck.radius;
    const rightWall = canvas.width - 20 - puck.radius;

    if (predictedX < leftWall) {
        const overshoot = leftWall - predictedX;
        predictedX = leftWall + overshoot;
    } else if (predictedX > rightWall) {
        const overshoot = predictedX - rightWall;
        predictedX = rightWall - overshoot;
    }

    if (predictedY < topWall) {
        const overshoot = topWall - predictedY;
        predictedY = topWall + overshoot;
    } else if (predictedY > bottomWall) {
        const overshoot = predictedY - bottomWall;
        predictedY = bottomWall - overshoot;
    }

    const scoreDiff = playerScore - aiScore;
    let errorMargin = config.errorMargin;
    let aggressiveness = config.aggressiveness;

    if (scoreDiff > 1) {
        errorMargin = Math.max(1, errorMargin - 4);
        aggressiveness = Math.min(0.42, aggressiveness + 0.04);
    } else if (scoreDiff < -2) {
        errorMargin = Math.min(35, errorMargin + 8);
        aggressiveness = Math.max(0.05, aggressiveness - 0.03);
    }

    if (aiDifficulty === 'hard') {
        errorMargin = Math.min(errorMargin, 4);
    }

    if (Math.random() < 0.02) {
        errorMargin += 12 + Math.random() * 12;
    }

    predictedY += (Math.random() - 0.5) * errorMargin;
    predictedX += (Math.random() - 0.5) * errorMargin * 0.3;

    predictedY = Math.max(ai.radius + 20, Math.min(canvas.height - ai.radius - 20, predictedY));

    const aiMinX = canvas.width / 2 + ai.radius + 10;
    const aiMaxX = canvas.width - ai.radius - 10;
    let aiTargetX = ai.x;

    if (puck.x > canvas.width / 2) {
        if (Math.abs(puck.x - ai.x) < 350) {
            const targetPos = Math.min(aiMaxX, Math.max(aiMinX, puck.x - ai.radius * 0.7));
            aiTargetX = ai.x + (targetPos - ai.x) * 0.5;
        } else {
            const targetPos = Math.min(aiMaxX, Math.max(aiMinX, predictedX - ai.radius * 0.4));
            aiTargetX = ai.x + (targetPos - ai.x) * 0.4;
        }
    } else {
        if (aiDifficulty === 'hard') {
            aiTargetX = Math.min(aiMaxX, canvas.width / 2 + ai.radius + 25);
        } else {
            aiTargetX = Math.min(aiMaxX, canvas.width / 2 + ai.radius + 50 + (puck.y - canvas.height / 2) * 0.08);
        }
    }

    const randomOffset = (Math.random() - 0.5) * (aiDifficulty === 'hard' ? 3 : 10);
    aiTargetX += randomOffset * 0.2;

    aiTargetX = Math.max(aiMinX, Math.min(aiMaxX, aiTargetX));

    if (aiHitsInRow > 3) {
        aiTargetX = Math.min(aiTargetX, canvas.width / 2 + ai.radius + 50);
    }

    ai.targetX = aiTargetX;
    ai.targetY = predictedY;

    return {
        targetX: aiTargetX,
        targetY: predictedY,
        speed: Math.min(0.35, aggressiveness + 0.05)
    };
}

function update() {
    if (gameOver || paused || goalAnimationActive || isNotificationActive || gameEnded) return;
    if (countdown > 0 && !isPuckLaunched) { countdown--; return; }
    if (!isPuckLaunched) return;

    const playerVelocity = updatePaddle(
        player, player.targetX, player.targetY,
        player.radius + 20, canvas.width / 2 - player.radius, 0.25
    );

    const aiDecision = updateAI();
    const aiVelocity = updatePaddle(
        ai, aiDecision.targetX, aiDecision.targetY,
        canvas.width / 2 + ai.radius, canvas.width - ai.radius - 20, aiDecision.speed
    );

    puck.x += puck.vx;
    puck.y += puck.vy;
    puck.vx *= 0.9995;
    puck.vy *= 0.9995;
    clampSpeed();
    createTrail();
    checkPuckStuck();

    if (puck.y - puck.radius <= 20) {
        puck.y = 20 + puck.radius;
        puck.vy *= -1;
        playHitSound(200, 0.03, 0.08);
        createParticles(puck.x, puck.y, 'rgba(0,0,0,0.2)', 4, 3);
        createImpactGlow(puck.x, 20, 'rgb(100, 100, 100)', 40, true);
    }
    if (puck.y + puck.radius >= canvas.height - 20) {
        puck.y = canvas.height - 20 - puck.radius;
        puck.vy *= -1;
        playHitSound(200, 0.03, 0.08);
        createParticles(puck.x, puck.y, 'rgba(0,0,0,0.2)', 4, 3);
        createImpactGlow(puck.x, canvas.height - 20, 'rgb(100, 100, 100)', 40, true);
    }

    const goalTop = canvas.height / 2 - GOAL_HEIGHT / 2;
    const goalBottom = canvas.height / 2 + GOAL_HEIGHT / 2;
    const insideGoal = puck.y > goalTop && puck.y < goalBottom;

    if (!insideGoal) {
        if (puck.x - puck.radius <= 20) {
            puck.x = 20 + puck.radius;
            puck.vx *= -1;
            playHitSound(200, 0.03, 0.08);
            createParticles(puck.x, puck.y, 'rgba(0,0,0,0.2)', 4, 3);
            createImpactGlow(20, puck.y, 'rgb(100, 100, 100)', 40, true);
        }
        if (puck.x + puck.radius >= canvas.width - 20) {
            puck.x = canvas.width - 20 - puck.radius;
            puck.vx *= -1;
            playHitSound(200, 0.03, 0.08);
            createParticles(puck.x, puck.y, 'rgba(0,0,0,0.2)', 4, 3);
            createImpactGlow(canvas.width - 20, puck.y, 'rgb(100, 100, 100)', 40, true);
        }
    }

    if (puck.x > canvas.width) {
        playerScore++;
        scorePop = 'player';
        playGoalSound();
        goalFlash = 0.8;
        goalAnimationActive = true;
        createImpactGlow(canvas.width - 20, puck.y, 'rgb(96, 165, 250)', 80, true);
        createCelebrationBurst(canvas.width - 50, puck.y, '#60a5fa', '#3b82f6', 'GOAL!');
        isPuckLaunched = false;
        stuckTimer = 0;
        stuckPuckResetTimer = 0;
        ai.hitCounter = 0;
        aiHitsInRow = 0;
        aiStuckTimer = 0;
        updateScoreDisplay();

        if (playerScore >= winScore) {
            gameOver = true;
            restartBtn.classList.add('show');
            readyText.classList.remove('show');
            pauseBtn.style.display = 'none';
            showCursor();
            setTimeout(() => {
                showFinalScore();
            }, 2500);
        } else if (playerScore === winScore - 1) {
            showMatchPoint();
        }
    }

    if (puck.x < 0) {
        aiScore++;
        scorePop = 'ai';
        playGoalSound();
        goalFlash = 0.8;
        goalAnimationActive = true;
        createImpactGlow(20, puck.y, 'rgb(248, 113, 113)', 80, true);
        createCelebrationBurst(50, puck.y, '#f87171', '#ef4444', 'GOAL!');
        isPuckLaunched = false;
        stuckTimer = 0;
        stuckPuckResetTimer = 0;
        ai.hitCounter = 0;
        aiHitsInRow = 0;
        aiStuckTimer = 0;
        updateScoreDisplay();

        if (aiScore >= winScore) {
            gameOver = true;
            restartBtn.classList.add('show');
            readyText.classList.remove('show');
            pauseBtn.style.display = 'none';
            showCursor();
            setTimeout(() => {
                showFinalScore();
            }, 2500);
        } else if (aiScore === winScore - 1) {
            showMatchPoint();
        }
    }

    handleCollision(player, playerVelocity);
    handleCollision(ai, aiVelocity);
    updateParticles();

    if (goalFlash > 0) goalFlash -= 0.02;
}

function drawTable() {
    ctx.fillStyle = '#f0f2f5';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 3;
    ctx.strokeRect(18, 18, canvas.width - 36, canvas.height - 36);

    ctx.strokeStyle = 'rgba(0,0,0,0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(22, 22, canvas.width - 44, canvas.height - 44);

    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 2;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, 20);
    ctx.lineTo(canvas.width / 2, canvas.height - 20);
    ctx.stroke();

    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 90, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(0,0,0,0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 80, 0, Math.PI * 2);
    ctx.stroke();

    const goalTop = canvas.height / 2 - GOAL_HEIGHT / 2;

    const playerGoalGrad = ctx.createLinearGradient(0, goalTop, 25, goalTop);
    playerGoalGrad.addColorStop(0, 'rgba(96, 165, 250, 0.15)');
    playerGoalGrad.addColorStop(1, 'rgba(96, 165, 250, 0)');
    ctx.fillStyle = playerGoalGrad;
    ctx.fillRect(0, goalTop, 25, GOAL_HEIGHT);

    const aiGoalGrad = ctx.createLinearGradient(canvas.width, goalTop, canvas.width - 25, goalTop);
    aiGoalGrad.addColorStop(0, 'rgba(248, 113, 113, 0.15)');
    aiGoalGrad.addColorStop(1, 'rgba(248, 113, 113, 0)');
    ctx.fillStyle = aiGoalGrad;
    ctx.fillRect(canvas.width - 25, goalTop, 25, GOAL_HEIGHT);

    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, goalTop, 20, GOAL_HEIGHT);
    ctx.strokeRect(canvas.width - 20, goalTop, 20, GOAL_HEIGHT);

    ctx.strokeStyle = 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 1;
    ctx.strokeRect(2, goalTop + 2, 16, GOAL_HEIGHT - 4);
    ctx.strokeRect(canvas.width - 18, goalTop + 2, 16, GOAL_HEIGHT - 4);

    const pocketRadius = 2.5;
    airPockets.forEach(pocket => {
        ctx.fillStyle = 'rgba(150, 155, 165, 0.25)';
        ctx.beginPath();
        ctx.arc(pocket.x, pocket.y, pocketRadius, 0, Math.PI * 2);
        ctx.fill();
    });
}

function drawStriker(x, y, radius, color, glowColor, isPlayer = true) {
    if (glowColor) {
        const grad = ctx.createRadialGradient(x, y, 0, x, y, radius * 1.5);
        grad.addColorStop(0, glowColor);
        grad.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(x, y, radius * 1.5, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.shadowColor = 'rgba(0,0,0,0.3)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 3;

    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.closePath();

    const outerGrad = ctx.createRadialGradient(
        x - radius * 0.3, y - radius * 0.3, radius * 0.1,
        x, y, radius
    );
    if (isPlayer) {
        outerGrad.addColorStop(0, '#93c5fd');
        outerGrad.addColorStop(0.3, '#60a5fa');
        outerGrad.addColorStop(0.7, '#3b82f6');
        outerGrad.addColorStop(1, '#1d4ed8');
    } else {
        outerGrad.addColorStop(0, '#fca5a5');
        outerGrad.addColorStop(0.3, '#f87171');
        outerGrad.addColorStop(0.7, '#ef4444');
        outerGrad.addColorStop(1, '#b91c1c');
    }
    ctx.fillStyle = outerGrad;
    ctx.fill();

    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    ctx.strokeStyle = isPlayer ? 'rgba(59, 130, 246, 0.5)' : 'rgba(239, 68, 68, 0.5)';
    ctx.lineWidth = 2;
    ctx.stroke();

    const innerRadius = radius * 0.55;
    ctx.beginPath();
    ctx.arc(x, y, innerRadius, 0, Math.PI * 2);
    ctx.closePath();

    const innerGrad = ctx.createRadialGradient(
        x - innerRadius * 0.3, y - innerRadius * 0.3, innerRadius * 0.1,
        x, y, innerRadius
    );
    if (isPlayer) {
        innerGrad.addColorStop(0, '#60a5fa');
        innerGrad.addColorStop(0.3, '#3b82f6');
        innerGrad.addColorStop(0.7, '#2563eb');
        innerGrad.addColorStop(1, '#1e40af');
    } else {
        innerGrad.addColorStop(0, '#f87171');
        innerGrad.addColorStop(0.3, '#ef4444');
        innerGrad.addColorStop(0.7, '#dc2626');
        innerGrad.addColorStop(1, '#991b1b');
    }
    ctx.fillStyle = innerGrad;
    ctx.fill();

    ctx.strokeStyle = isPlayer ? 'rgba(30, 58, 138, 0.4)' : 'rgba(127, 29, 29, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    const highlight = ctx.createRadialGradient(
        x - radius * 0.3, y - radius * 0.3, radius * 0.05,
        x - radius * 0.2, y - radius * 0.2, radius * 0.5
    );
    highlight.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
    highlight.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = highlight;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();

    const innerHighlight = ctx.createRadialGradient(
        x - innerRadius * 0.25, y - innerRadius * 0.25, innerRadius * 0.05,
        x - innerRadius * 0.15, y - innerRadius * 0.15, innerRadius * 0.4
    );
    innerHighlight.addColorStop(0, 'rgba(255, 255, 255, 0.3)');
    innerHighlight.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = innerHighlight;
    ctx.beginPath();
    ctx.arc(x, y, innerRadius, 0, Math.PI * 2);
    ctx.fill();

    const reflection = ctx.createRadialGradient(
        x + radius * 0.2, y + radius * 0.3, radius * 0.05,
        x + radius * 0.2, y + radius * 0.4, radius * 0.3
    );
    reflection.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
    reflection.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = reflection;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = isPlayer ? 'rgba(30, 58, 138, 0.3)' : 'rgba(127, 29, 29, 0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    const flatY = y + radius * 0.85;
    ctx.moveTo(x - radius * 0.45, flatY);
    ctx.lineTo(x + radius * 0.45, flatY);
    ctx.stroke();

    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
}

function drawGlow(x, y, radius, color) {
    const grad = ctx.createRadialGradient(x, y, radius * 0.1, x, y, radius * 1.8);
    grad.addColorStop(0, color);
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, radius * 1.8, 0, Math.PI * 2);
    ctx.fill();
}

function drawCircle(x, y, radius, color, glowColor = null) {
    if (glowColor) drawGlow(x, y, radius, glowColor);

    ctx.shadowColor = 'rgba(0,0,0,0.2)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 1;
    ctx.shadowOffsetY = 2;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
}

function drawParticles() {
    particles.forEach(p => {
        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * p.life, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.globalAlpha = 1;
}

function drawTrails() {
    trails.forEach(t => {
        ctx.globalAlpha = t.life * 0.15;
        ctx.fillStyle = '#3b82f6';
        ctx.beginPath();
        ctx.arc(t.x, t.y, t.radius * t.life, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.globalAlpha = 1;
}

function drawGoalFlash() {
    if (goalFlash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${goalFlash * 0.15})`;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
}

function gameLoop(timestamp) {
    if (!lastTimestamp) {
        lastTimestamp = timestamp;
    }

    let delta = (timestamp - lastTimestamp) / 1000;
    if (delta > 0.1) delta = 0.1;
    lastTimestamp = timestamp;

    accumulator += delta;

    while (accumulator >= FIXED_DT) {
        update();
        accumulator -= FIXED_DT;
    }

    drawTable();
    drawTrails();
    drawImpactGlows();
    drawParticles();
    drawGoalFlash();

    drawStriker(ai.x, ai.y, ai.radius, '#ef4444', 'rgba(239, 68, 68, 0.08)', false);
    drawStriker(player.x, player.y, player.radius, '#3b82f6', 'rgba(59, 130, 246, 0.08)', true);

    if (isPuckLaunched || gameOver) {
        drawCircle(puck.x, puck.y, puck.radius, '#f97316', 'rgba(249, 115, 22, 0.15)');
        ctx.beginPath();
        ctx.arc(puck.x, puck.y, puck.radius * 0.3, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(194, 65, 12, 0.4)';
        ctx.fill();
    }

    if (celebrationParticles.length > 0) {
        updateCelebration();
        drawCelebration();
    }

    requestAnimationFrame(gameLoop);
}

// Initialize
updateScoreDisplay();
resetPuck();
initAudio();

lastTimestamp = performance.now();
requestAnimationFrame(gameLoop);

window.addEventListener('resize', () => {
    resize();
    generateAirPockets();
    player.x = Math.min(player.x, canvas.width / 2 - player.radius);
    ai.x = Math.max(ai.x, canvas.width / 2 + ai.radius);
});